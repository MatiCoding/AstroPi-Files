# Code made by Students from the high school Isla de la Deva (Spain)
# AstroPi Group: AstroTrox (Unai Rivero Hueso and Mateo Rubio Zamarreño)

# Import all the modules we are going to use (Getting the position of the ISS, the Artifical Intelligent, the one for the treatment of the images.
from datetime import datetime, timedelta
from time import sleep
from picamera import PiCamera
from orbit import ISS
import os
from pathlib import Path
from PIL import Image
from pycoral.adapters import common
from pycoral.adapters import classify
from pycoral.utils.edgetpu import make_interpreter
from pycoral.utils.dataset import read_label_file

# We create a function which work is to analyze the images and tell if they are pictures of day, night or twilight.
#see https://projects.raspberrypi.org/en/projects/image-id-coral/
def AI():
    script_dir = Path(__file__).parent.resolve()
    model_file = script_dir/'astropi-day-vs-nite.tflite' # This is the file that has the IA in it.
    data_dir = script_dir
    label_file = data_dir/'day-vs-night.txt' # Name of the label file.
    image_file = data_dir/'image.jpg' # Name of the file it will analyze.

    interpreter = make_interpreter(f"{model_file}")
    interpreter.allocate_tensors()
    size = common.input_size(interpreter)
    image = Image.open(image_file).convert('RGB').resize(size, Image.ANTIALIAS)

    common.set_input(interpreter, image)
    interpreter.invoke()

    classes = classify.get_classes(interpreter, top_k=1)
    labels = read_label_file(label_file)
    
    #This is in order to save or not the picture, it will be explain later on in the code.
    
    for c in classes:
        time = labels.get(c.id,c.id)
        value = c.score
        
        if time == "day" and value >= 0.4:
            return 1
        elif time == "cloud" and value >= 0.4:
            return 2
        else:
            return 0

# The program starts here

try:
    script_dir = Path(__file__).parent.resolve()
    image_file = str(script_dir/'image.jpg') # Name of the file it will analyze.
   # We set the actual time and set a camera module to a variable.
    start_time = datetime.now()
    camara = PiCamera()
    i = 1
    j = 1
    now_time = datetime.now()

    # This is the actual program, it is a loop that will be working for 3 hours or less.
    while (now_time < start_time + timedelta(minutes=179)):
        # It takes the position of the ISS and writes it in the image that is taken (called "image.jpg")
        location = ISS.coordinates()
        camara.annotate_text = "lat:"+str(round(location.latitude.degrees,2))+" long:"+str(round(location.longitude.degrees,2))+" Time:"+str(now_time)
        camara.capture(image_file)
    
        valor=AI()
        # If the result of the function is 1, it will rename the "image.jpg" with just a number. If not, it will remove the "image.jpg")
        if valor == 1:
            os.rename(image_file,f"imageDay{i}.jpg")
            i = i+1
        elif valor == 2:
            os.rename(image_file,f"imageCloud{j}.jpg")
            j = j+1
        else:
            os.remove(image_file)
    
        sleep (10)
    
        now_time = datetime.now() # It refresh the actual time. 

except:
    exit()